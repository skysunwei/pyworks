# IN 后面内容是 公会长 zxs id

SELECT saler.userid, saler.pid,
	'' AS orders,
(CASE
     WHEN vipuser_rebate.user_id > 0 THEN 1
     ELSE 0
 END) 'vip'
FROM saler
	LEFT JOIN vipuser_rebate ON saler.userid = vipuser_rebate.user_id
WHERE saler.status=1
	AND saler.pid != 0
    AND saler.userid NOT IN (237)